package com.example.monopatin.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;

@Entity
public class Pausa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private LocalDate fechaInicio;

    @Column
    private LocalDate fechaFin;

    @Column Long pausaTotal;
    @ManyToOne
    @JoinColumn(name = "idviaje")
    private Viaje viaje;

    public Pausa() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Pausa(Long id, LocalDate fechaInicio, LocalDate fechaFin, Viaje viaje) {
        this.id = id;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.pausaTotal = 0L;
        this.viaje = viaje;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
        //this.setCantidadPausa();
    }

    public Viaje getRegistroUsoMonopatin() {
        return viaje;
    }

    public Long getPausaTotal() {
        return pausaTotal;
    }

    public void setPausaTotal(Long pausaTotal) {
        this.pausaTotal = pausaTotal;
    }

    public Long getCantidadPausa(){
        return getFechaInicio().until(getFechaFin(), ChronoUnit.MINUTES);
    }

    public void setViaje(Viaje viaje) {
        this.viaje = viaje;
    }

    /*public void setCantidadPausa(){
        this.pausaTotal = getFechaInicio().until(getFechaFin(), ChronoUnit.MINUTES);
    }*/
}
