package com.example.monopatin.service.dto;

import lombok.Getter;

@Getter
public class ReporteKilometrajeDTO {

    private Long idMonopatin;

    private Double kilometraje;
    private Long tiempoDePausa;

    public ReporteKilometrajeDTO(Long idMonopatin, Double kilometraje, Long tiempoDePausa) {
        this.idMonopatin = idMonopatin;
        this.kilometraje = kilometraje;
        this.tiempoDePausa = tiempoDePausa;
    }

    public ReporteKilometrajeDTO(Long idMonopatin, Double kilometraje) {
        this.idMonopatin = idMonopatin;
        this.kilometraje = kilometraje;
        this.tiempoDePausa = null;
    }
}
