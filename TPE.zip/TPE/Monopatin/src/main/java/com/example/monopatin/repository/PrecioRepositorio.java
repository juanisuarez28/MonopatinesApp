package com.example.monopatin.repository;

import com.example.monopatin.model.Precio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PrecioRepositorio extends JpaRepository<Precio, Long> {

}
