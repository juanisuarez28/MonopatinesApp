package com.example.monopatin.service.dto;

import com.example.monopatin.model.Pausa;
import com.example.monopatin.model.Viaje;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class PausaDTO {
    private Long id;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private Viaje viaje;

    public PausaDTO(Long id, LocalDate fechaInicio, LocalDate fechaFin, Viaje viaje) {
        this.id = id;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.viaje = viaje;
    }

    public PausaDTO(Pausa p) {
        this.id = p.getId();
        this.fechaInicio = p.getFechaInicio();
        this.fechaFin = p.getFechaFin();
        this.viaje = p.getRegistroUsoMonopatin();
    }

    public Long getId() {
        return id;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public Viaje getRegistroUsoMonopatin() {
        return viaje;
    }
}
