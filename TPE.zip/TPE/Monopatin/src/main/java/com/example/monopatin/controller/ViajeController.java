package com.example.monopatin.controller;

import com.example.monopatin.model.Viaje;
import com.example.monopatin.service.ViajeServicio;
import com.example.monopatin.service.dto.ReporteKilometrajeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/viajes")
public class ViajeController {
    private ViajeServicio rs;

    @Autowired
    public ViajeController(ViajeServicio rs){
        this.rs = rs;

    }

    @GetMapping("")
    public ResponseEntity<?> getAll(){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(rs.findAll());
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente más tarde.\"}");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOne(@PathVariable Long id){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(rs.findById(id));
        }catch (Exception e ){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. No se encuentra el objeto buscado" +
                    ".\"}");
        }
    }

    @PostMapping("")
    public ResponseEntity<?> save(@RequestBody Viaje entity){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(rs.save(entity));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. No se pudo ingresar, revise los campos e intente nuevamente.\"}");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id,@RequestBody Viaje entity){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(rs.update(id,entity));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. No se pudo editar, revise los campos e intente nuevamente.\"}");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id){
        try{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(rs.delete(id));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. no se pudo eliminar intente nuevamente.\"}");
        }
    }

    @GetMapping("/getReporteKilometraje/{umbral}")
    public ResponseEntity<?> getReporteKilometraje(@PathVariable Long umbral,
                                                   @RequestParam(name = "conPausas", required = false, defaultValue = "false") boolean conPausas){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(rs.getReporteKilometraje(umbral, conPausas));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente más tarde.\"}");

        }
    }

    @GetMapping("/facturado/{anio}/{mesInicio}/{mesFin}")
    public ResponseEntity<?> getFacturadoEntreMeses(@PathVariable int anio, @PathVariable int mesInicio, @PathVariable int mesFin){

        try{
            return ResponseEntity.status(HttpStatus.OK).body(rs.getFacturadoEntreMeses(anio, mesInicio, mesFin));
        }catch (Exception e ){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente más tarde.\"}");
        }
    }
}
