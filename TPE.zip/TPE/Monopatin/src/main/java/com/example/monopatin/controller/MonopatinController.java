package com.example.monopatin.controller;

import com.example.monopatin.model.Monopatin;
import com.example.monopatin.model.Viaje;
import com.example.monopatin.service.MonopatinServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/monopatin")
public class MonopatinController {
    private MonopatinServicio ms;

    @Autowired
    public MonopatinController(MonopatinServicio ms){
        this.ms=ms;
    }

    @Autowired
    private RestTemplate restTemplate;


    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(ms.findById(id));
        }catch (Exception e ){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. No se encuentra el objeto buscado" +
                    ".\"}");
        }
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<?> update(@PathVariable Long id,@RequestBody Monopatin entity){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(ms.update(id,entity));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. No se pudo editar, revise los campos e intente nuevamente.\"}");
        }
    }

    @GetMapping("/viaje/{viajeId}")
    public ResponseEntity<Viaje> obtenerViajePorId(@PathVariable Long viajeId) {
        Viaje viaje = restTemplate.getForObject("http://viajes-service/viajes/{viajeId}", Viaje.class, viajeId);
        return ResponseEntity.ok(viaje);
    }

    @PostMapping("/agregar")
    public ResponseEntity<?> agregarMonopatin(@RequestBody Monopatin m){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(ms.save(m));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. No se pudo agregar, revise los campos e intente nuevamente.\"}");
        }
    }

    @DeleteMapping("/eliminar/{idMonopatin}")
    public ResponseEntity<?> eliminarMonopatin(@PathVariable Long idMonopatin){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(ms.delete(idMonopatin));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. No se pudo editar, revise los campos e intente nuevamente.\"}");
        }
    }

    @GetMapping ("/viajesPorAnio/{cantViajes}/{anio}")
    public ResponseEntity<?> getMonopatinPorAnio(@PathVariable int cantViajes, int anio){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(ms.getMonopatinPorAnio(cantViajes, anio));
        }catch (Exception e ){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. No se encuentra el objeto buscado" +
                    ".\"}");        }
    }

    @GetMapping("/comparacionEstados")
    public ResponseEntity<?> getComparacionEstados(){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(ms.getComparacionEstados());
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. No se encuentra el objeto buscado" +
                    ".\"}");
        }
    }










}

