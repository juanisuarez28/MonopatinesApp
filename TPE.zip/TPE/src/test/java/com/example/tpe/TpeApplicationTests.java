package com.example.tpe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpeApplicationTests {

    @Test
    void contextLoads() {
    }

}
