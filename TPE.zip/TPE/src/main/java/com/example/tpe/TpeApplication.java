package com.example.tpe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpeApplication {

    public static void main(String[] args) {
        SpringApplication.run(TpeApplication.class, args);
    }

}
