package com.example.parada.service.dto;

import com.example.parada.model.Parada;
import lombok.Getter;

import java.io.Serializable;
import java.util.List;

@Getter
public class ParadaDTO {

    private long id;
    private double x;
    private double y;
    private List<Long> monopatinesEnLaParada;

    public ParadaDTO(long id, Long x, Long y, List<Long> monopatinesEnLaParada) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.monopatinesEnLaParada = monopatinesEnLaParada;
    }

    public ParadaDTO(Parada p){
        this.id = p.getId();
        this.x = p.getX();
        this.y = p.getY();
        this.monopatinesEnLaParada = p.getMonopatinesEnLaParada();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getX() {
        return x;
    }

    public void setX(Long x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(Long y) {
        this.y = y;
    }

    public List<Long> getMonopatinesEnLaParada() {
        return monopatinesEnLaParada;
    }

    public void setMonopatinesEnLaParada(List<Long> monopatinesEnLaParada) {
        this.monopatinesEnLaParada = monopatinesEnLaParada;
    }
}

