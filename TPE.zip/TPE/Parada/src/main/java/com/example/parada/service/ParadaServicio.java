package com.example.parada.service;

import com.example.parada.model.Parada;
import com.example.parada.service.dto.MonopatinDTO;
import com.example.parada.repository.ParadaRepositorio;
import com.example.parada.service.dto.ParadaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ParadaServicio {
    private ParadaRepositorio pr;
    private double umbral = 100.0;

    @Autowired
    public ParadaServicio(ParadaRepositorio pr) {
        this.pr = pr;
    }

    @Transactional
    public ParadaDTO findById(Long id) {
        return pr.findById(id).map(ParadaDTO::new).orElse(null);
    }

    @Transactional
    public List<ParadaDTO> findAll() throws Exception {
        return pr.findAll().stream().map(ParadaDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public ParadaDTO save(Parada entity) throws Exception {
        pr.save(entity);
        return this.findById(entity.getId());
    }

    @Transactional
    public ParadaDTO update(Long id, Parada entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        pr.deleteById(id);
        return this.findById(id) != null;
    }

    @Transactional
    public List<ParadaDTO> getMonopatinesCercanos(double x, double y) {

        return this.pr.getMonopatinesCercanos(x, y, this.umbral);
    }
}
