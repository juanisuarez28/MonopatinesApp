package com.example.administracion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdministracionApplicationTests {

    @Test
    void contextLoads() {
    }

}
