package com.example.administracion.model.clases;


import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@Data
public class Mantenimiento implements Serializable {

    private Long id;
    private Long id_monopatin;
    private LocalDateTime inicio;
    private LocalDateTime fin;
    private int km_recorridos;

    public Mantenimiento(Long id, Long id_monopatin, LocalDateTime inicio, LocalDateTime fin, int km_recorridos) {
        this.id = id;
        this.id_monopatin = id_monopatin;
        this.inicio = inicio;
        this.fin = fin;
        this.km_recorridos = km_recorridos;
    }

    public Mantenimiento() {

    }

    public Long getId() {
        return id;
    }

    public Long getId_monopatin() {
        return id_monopatin;
    }

    public LocalDateTime getInicio() {
        return inicio;
    }

    public LocalDateTime getFin() {
        return fin;
    }

    public int getKm_recorridos() {
        return km_recorridos;
    }


}

