package com.example.administracion.repository;

import com.example.administracion.model.Administrador;
import com.example.administracion.model.Rol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdministracionRepo extends JpaRepository<Administrador, Long> {
}
