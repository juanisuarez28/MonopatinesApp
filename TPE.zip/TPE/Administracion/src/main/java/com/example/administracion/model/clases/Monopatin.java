package com.example.administracion.model.clases;


import jakarta.persistence.*;
import lombok.Data;
import org.springframework.stereotype.Repository;

import java.io.Serializable;

@Data
public class Monopatin implements Serializable {

    private Long id;

    private String numeroSerie;
    private double kilometraje;
    private boolean enMantenimiento;

    public Monopatin(Long id, String numeroSerie, double kilometraje, boolean enMantenimiento) {
        this.id = id;
        this.numeroSerie = numeroSerie;
        this.kilometraje = kilometraje;
        this.enMantenimiento = enMantenimiento;
    }

    public Monopatin(Monopatin m){
        this.id = m.getId();
        this.numeroSerie = m.getNumeroSerie();
        this.kilometraje = m.getKilometraje();
        this.enMantenimiento = m.isEnMantenimiento();
    }

    public Long getId() {
        return id;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public double getKilometraje() {
        return kilometraje;
    }

    public boolean isEnMantenimiento() {
        return enMantenimiento;
    }

}
