package com.example.administracion.model.clases;

import lombok.Getter;

import java.util.Date;

@Getter
public class Viaje {
    private Long id;
    private Monopatin monopatinId;
    private Date fechaInicio;
    private Date fechaFin;
    private double kilometrosRecorridos;

    public Viaje(Long id, Monopatin monopatin, Date fechaInicio, Date fechaFin, double kilometrosRecorridos) {
        this.id = id;
        this.monopatinId = monopatin;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.kilometrosRecorridos = kilometrosRecorridos;
    }

    public Viaje(Viaje r) {
        this.id = r.getId();
        this.monopatinId = r.getMonopatinId();
        this.fechaInicio = r.getFechaInicio();
        this.fechaFin = r.getFechaFin();
        this.kilometrosRecorridos = r.getKilometrosRecorridos();
    }

    public Long getId() {
        return id;
    }

    public Monopatin getMonopatinId() {
        return monopatinId;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public double getKilometrosRecorridos() {
        return kilometrosRecorridos;
    }


}
