package com.example.administracion.service.dto;

import lombok.Getter;

@Getter
public class ReporteKilometrajeDTO {

    private Long idMonopatin;

    private Long kilometraje;

    public ReporteKilometrajeDTO(Long idMonopatin, Long kilometraje) {
        this.idMonopatin = idMonopatin;
        this.kilometraje = kilometraje;
    }
}
