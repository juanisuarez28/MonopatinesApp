package com.example.administracion.service;

import com.example.administracion.model.Administrador;
import com.example.administracion.model.clases.*;
import com.example.administracion.repository.AdministracionRepo;
import com.example.administracion.service.dto.AdministradorDTO;
import com.example.administracion.service.dto.ReporteKilometrajeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ServicioAdministracion {
    private RestTemplate restTemplate;
    private AdministracionRepo ar;

    @Autowired
    public ServicioAdministracion(AdministracionRepo ar) {
        this.ar = ar;
    }

    @Transactional
    public ResponseEntity settearMonopatinAMantenimiento(Long id) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Monopatin> response = restTemplate.exchange("http://localhost:8003/monopatin/" + id,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Monopatin>() {
                });
        if (response.getStatusCode().is2xxSuccessful()) {
            Monopatin monopatin = response.getBody();
            if (!monopatin.isEnMantenimiento()) {
                this.agregarMantenimiento(id);
                monopatin.setEnMantenimiento(true);
                HttpEntity<Monopatin> requestEntity2 = new HttpEntity<>(monopatin, headers);
                ResponseEntity<Monopatin> response2 = restTemplate.exchange("http://localhost:8003/monopatin/editar/" + id,
                        HttpMethod.PUT, requestEntity2, new ParameterizedTypeReference<Monopatin>() {
                        });
                return response2;
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el monopatin a dar de alta");
    }

    @Transactional

    public ResponseEntity finMantenimientoMonopatin(Long id) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Monopatin> response = restTemplate.exchange("http://localhost:8003/monopatin/" + id,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Monopatin>() {
                });
        if (response.getStatusCode().is2xxSuccessful()) {
            Monopatin monopatin = response.getBody();
            if (monopatin.isEnMantenimiento()) {
                this.finMantenimiento(id);
                monopatin.setEnMantenimiento(false);
                HttpEntity<Monopatin> requestEntity2 = new HttpEntity<>(monopatin, headers);
                ResponseEntity<Monopatin> response2 = restTemplate.exchange("http://localhost:8003/monopatin/editar/" + id,
                        HttpMethod.PUT, requestEntity2, new ParameterizedTypeReference<Monopatin>() {
                        });
                return response2;
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el monopatin en mantenimiento a dar de baja");
    }

    @Transactional
    public void finMantenimiento(Long idMonopatin) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Mantenimiento> response = restTemplate.exchange("http://localhost:8003/mantenimiento/getMonopatin/" + idMonopatin,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Mantenimiento>() {
                });

        if (response.getStatusCode().is2xxSuccessful()) {
            Mantenimiento m = response.getBody();
            Long idMantenimento = m.getId();
            m.setFin(LocalDateTime.now());
            HttpEntity<Mantenimiento> requestEntity2 = new HttpEntity<>(m, headers);
            ResponseEntity<Mantenimiento> response2 = restTemplate.exchange("http://localhost:8003/monopatin/editar/" + idMantenimento,
                    HttpMethod.PUT, requestEntity2, new ParameterizedTypeReference<Mantenimiento>() {
                    });
        }
    }

    @Transactional

    public ResponseEntity agregarMantenimiento(Long id) {
        HttpHeaders headers = new HttpHeaders();
        Mantenimiento mantenimiento = new Mantenimiento();

        mantenimiento.setId_monopatin(id);
        mantenimiento.setInicio(LocalDateTime.now());
        mantenimiento.setFin(null);

        HttpEntity<Mantenimiento> requesEntity = new HttpEntity<>(mantenimiento, headers);

        ResponseEntity<String> response = restTemplate.exchange("http://localhost:8003/mantenimiento/agregar",
                HttpMethod.POST, requesEntity, String.class);
        return response;
    }

    @Transactional

    public ResponseEntity agregarMonopatin(Monopatin m) {
        HttpHeaders headers = new HttpHeaders();

        Monopatin monopatinNuevo = new Monopatin(m);
        HttpEntity<Monopatin> requestEntity = new HttpEntity<>(monopatinNuevo, headers);
        ResponseEntity<String> response = restTemplate.exchange("http://localhost:8003/monopatin/agregar",
                HttpMethod.POST, requestEntity, String.class);
        return response;
    }

    @Transactional

    public ResponseEntity deleteMonopatin(Long idMonopatin) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Monopatin> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange("http://localhost:8003/monopatin/eliminar/" + idMonopatin,
                HttpMethod.DELETE, requestEntity, String.class);
        if (response.hasBody()) {
            return ResponseEntity.ok("Monopatin eliminado con exito");//200 ok
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Monopatin a eliminar no encontrado");
    }

    @Transactional

    public ResponseEntity agregarParada(Parada p) {
        HttpHeaders headers = new HttpHeaders();

        Parada paradaNueva = new Parada(p);
        HttpEntity<Parada> requestEntity = new HttpEntity<>(paradaNueva, headers);
        ResponseEntity<String> response = restTemplate.exchange("http://localhost:8003/parada/agregar",
                HttpMethod.POST, requestEntity, String.class);
        return response;
    }

    @Transactional

    public ResponseEntity deleteParada(Long idParada) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Parada> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange("http://localhost:8003/parada/eliminar/" + idParada,
                HttpMethod.DELETE, requestEntity, String.class);
        if (response.hasBody()) {
            return ResponseEntity.ok("Parada eliminada con exito");//200 ok
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Parada a eliminar no encontrada");
    }

    @Transactional
    public ResponseEntity anularCuenta(Long idCuenta) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Cuenta> response = restTemplate.exchange("http://localhost:8003/cuenta/" + idCuenta,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Cuenta>() {
                });
        if (response.getStatusCode().is2xxSuccessful()) {
            Cuenta cuenta = response.getBody();
            if (!cuenta.isAnulada()) {
                cuenta.setAnulada(true);
                HttpEntity<Cuenta> requestEntity2 = new HttpEntity<>(cuenta, headers);
                ResponseEntity<Cuenta> response2 = restTemplate.exchange("http://localhost:8003/cuenta/anular/" + idCuenta,
                        HttpMethod.PUT, requestEntity2, new ParameterizedTypeReference<Cuenta>() {
                        });
                return response2;
            } else {
                return ResponseEntity.status(HttpStatus.OK).body("Esta cuenta ya está anulada");
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró la cuenta a anular");
    }

    @Transactional
    public ResponseEntity habilitarCuenta(Long idCuenta) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Cuenta> response = restTemplate.exchange("http://localhost:8003/cuenta/" + idCuenta,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Cuenta>() {
                });
        if (response.getStatusCode().is2xxSuccessful()) {
            Cuenta cuenta = response.getBody();
            if (cuenta.isAnulada()) {
                cuenta.setAnulada(false);
                HttpEntity<Cuenta> requestEntity2 = new HttpEntity<>(cuenta, headers);
                ResponseEntity<Cuenta> response2 = restTemplate.exchange("http://localhost:8003/cuenta/habilitar/" + idCuenta,
                        HttpMethod.PUT, requestEntity2, new ParameterizedTypeReference<Cuenta>() {
                        });
                return response2;
            } else {
                return ResponseEntity.status(HttpStatus.OK).body("Esta cuenta ya está habilitada");
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró la cuenta a habilitar");
    }

    @Transactional
    public List<AdministradorDTO> findAll() throws Exception {
        return ar.findAll().stream().map(AdministradorDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public AdministradorDTO findById(Long id) throws Exception {
        return ar.findById(id).map(AdministradorDTO::new).orElse(null);
    }

    @Transactional
    public AdministradorDTO save(Administrador entity) throws Exception {
        ar.save(entity);
        return this.findById(entity.getId().longValue());
    }

    @Transactional
    public AdministradorDTO update(Long id, Administrador entity) throws Exception {
        return this.save(entity);
    }

    @Transactional
    public boolean delete(Long id) throws Exception {
        ar.deleteById(id);
        return this.findById(id) != null;
    }

    @Transactional
    public ResponseEntity<?> getKilometraje(Long umbral, boolean incluirPausas) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        if (incluirPausas) {
            ResponseEntity<List<ReporteKilometrajeDTO>> response = restTemplate.exchange("http://localhost:8003/viajes/getReporteKilometraje/" + umbral + "?incluirPausas=true",
                    HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<ReporteKilometrajeDTO>>() {
                    });
            return response;
        } else {
            ResponseEntity<List<ReporteKilometrajeDTO>> response = restTemplate.exchange("http://localhost:8003/viajes/getReporteKilometraje/" + umbral,
                    HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<ReporteKilometrajeDTO>>() {
                    });
            return response;
        }
    }

    @Transactional
    public ResponseEntity<?> getMonopatinesPorAnio(int cantViajes, int anio) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<?> response = restTemplate.exchange("http://localhost:8003/monopatin/viajesPorAnio/" + cantViajes + "/" + anio,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<Monopatin>>() {
                });

        return response;
    }

    @Transactional
    public ResponseEntity<?> getTotalFacturadoEntreMeses(int anio, int mesInicio, int mesFin) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<?> response = restTemplate.exchange("http://localhost:8003/viajes/facturado/" + anio + "/" + mesInicio + "/" + mesFin,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Integer>() {
                });

        return response;
    }

    @Transactional
    public ResponseEntity<?> getComparacionEstados(){
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<?> response = restTemplate.exchange("http://localhost:8003/monopatin/comparacionEstados",
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Map<String,Long>>() {
                });

        return response;
    }

    @Transactional
    public ResponseEntity<?> getMonopatinesCercanos(Long idUsuario) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Usuario> response = restTemplate.exchange("http://localhost:8003/usuarios/" + idUsuario,
                HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Usuario>() {
                });
        if(response.getStatusCode().is2xxSuccessful()){
            Usuario usuario = response.getBody();

            ResponseEntity<?> response2 = restTemplate.exchange("http://localhost:8003/parada/monopatinesCercanos/" + usuario.getX() +"/" + usuario.getY(),
                    HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Usuario>() {
                    });
            return response2;
        }
        return response;
    }
}


