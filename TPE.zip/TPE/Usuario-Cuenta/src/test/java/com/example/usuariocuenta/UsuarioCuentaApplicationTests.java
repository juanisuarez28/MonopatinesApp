package com.example.usuariocuenta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioCuentaApplicationTests {

    @Test
    void contextLoads() {
    }

}
