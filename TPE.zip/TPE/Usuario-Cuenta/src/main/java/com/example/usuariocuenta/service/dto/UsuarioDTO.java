package com.example.usuariocuenta.service.dto;

import com.example.usuariocuenta.model.Cuenta;
import com.example.usuariocuenta.model.Usuario;
import jakarta.persistence.*;
import lombok.Getter;

@Getter
public class UsuarioDTO {
    private long id;
    private String cel;
    private String email;
    private String nombre;
    private String apellido;

    private Cuenta cuenta;

    public UsuarioDTO(long id, String cel, String email, String nombre, String apellido, Cuenta cuenta) {
        this.id = id;
        this.cel = cel;
        this.email = email;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cuenta = cuenta;
    }

    public UsuarioDTO(Usuario u){
        this.id = u.getId();
        this.cel = u.getCel();
        this.email = u.getEmail();
        this.nombre = u.getNombre();
        this.apellido = u.getApellido();
        this.cuenta = u.getCuenta();
    }

    public long getId() {
        return id;
    }


    public String getCel() {
        return cel;
    }


    public String getEmail() {
        return email;
    }


    public String getNombre() {
        return nombre;
    }


    public String getApellido() {
        return apellido;
    }

}
