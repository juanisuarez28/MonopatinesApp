package com.example.usuariocuenta.service;

import com.example.usuariocuenta.model.Cuenta;
import com.example.usuariocuenta.repository.CuentaRepositorio;
import com.example.usuariocuenta.service.dto.CuentaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuentaServicio {
    private CuentaRepositorio cr;

    @Autowired
    public CuentaServicio(CuentaRepositorio cr){
        this.cr=cr;
    }

    @Transactional
    public CuentaDTO findById(Long id) {
        return cr.findById(id).map(CuentaDTO::new).orElse(null);
    }

    @Transactional
    public List<CuentaDTO> findAll() throws Exception {
        return cr.findAll().stream().map(CuentaDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public CuentaDTO save(Cuenta entity) throws Exception {
        cr.save(entity);
        return this.findById(entity.getId().longValue());
    }

    @Transactional
    public CuentaDTO update(Long id, Cuenta entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        cr.deleteById(id);
        return this.findById(id) != null;
    }

    @Transactional
    public CuentaDTO anularCuenta(Long id) throws Exception {
        CuentaDTO response = this.findById(id);
        Cuenta cuenta = new Cuenta(response.getId(), response.getDate(), true, response.getUsuarios());
        return  this.save(cuenta);
    }

    @Transactional
    public CuentaDTO habilitarCuenta(Long id) throws Exception {
        CuentaDTO response = this.findById(id);
        Cuenta cuenta = new Cuenta(response.getId(), response.getDate(), response.getUsuarios());
        return  this.save(cuenta);
    }
}
