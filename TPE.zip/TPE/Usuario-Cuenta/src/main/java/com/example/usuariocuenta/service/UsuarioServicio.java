package com.example.usuariocuenta.service;

import com.example.usuariocuenta.model.Usuario;
import com.example.usuariocuenta.repository.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.usuariocuenta.service.dto.UsuarioDTO;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UsuarioServicio {
    private UsuarioRepositorio ur;

    @Autowired
    public UsuarioServicio(UsuarioRepositorio ur){
        this.ur=ur;
    }

    @Transactional
    public List<UsuarioDTO> findAll() throws Exception {
        return ur.findAll().stream().map(UsuarioDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public UsuarioDTO findById(Long id) throws Exception {
        return ur.findById(id).map(UsuarioDTO::new).orElse(null);
    }

    @Transactional
    public UsuarioDTO save(Usuario entity) throws Exception {
        ur.save(entity);
        return this.findById(entity.getId());
    }

    @Transactional
    public UsuarioDTO update(Long id,Usuario entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        ur.deleteById(id);
        return this.findById(id) != null;
    }

}
